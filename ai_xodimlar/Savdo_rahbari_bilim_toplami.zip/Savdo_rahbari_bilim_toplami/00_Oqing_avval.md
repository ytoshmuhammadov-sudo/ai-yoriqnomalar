# SAVDO RAHBARI BILIM TO‘PLAMI

AI-Savdo rahbari uchun 7 ta o‘zbekcha bilim fayli. Ular bilan xodim skript, e’tirozlarga javob, yozishma tahlili va savdo bo‘limini boshqarishda siz bilan birga ishlaydi.

## Ichida
01. Savdo bo‘limi tuzilishi va CRM
02. Yozishma skriptlari (Instagram, Telegram)
03. Qo‘ng‘iroq skripti
04. E’tirozlar bazasi: 20 ta tayyor javob
05. Qayta aloqa va mijozni ushlab qolish
06. Sotuvchini yollash, o‘rgatish va motivatsiya
07. Kunlik nazorat, hisobot va KPI

## Qanday yuklanadi
1. ZIP faylni oching: sichqonchaning o‘ng tugmasi → "Extract All" (Hammasini chiqarish).
2. claude.ai → Projects → AI-Savdo rahbari loyihasi.
3. Files → ＋ → Upload from device → 01-07 fayllarni tanlang.
4. Bu faylni (00) yuklash shart emas.
5. Loyiha ichida yangi chat oching: "Bilim fayllaringni o‘qi. Mijoz 'qimmat ekan' deb yozdi: 3 xil javob variantini ber."

## Muhim
Skriptlardagi [qavs] ichini o‘z mahsulotingiz va shartlaringiz bilan almashtiring. Eng yaxshi skript: sizning muvaffaqiyatli yozishmalaringiz. Ularni ham loyihaga qo‘shing.
