# MARKETOLOG BILIM TO‘PLAMI

AI-Marketolog uchun 8 ta o‘zbekcha bilim fayli. Ularni Claude loyihangizga qo‘shsangiz, xodim marketing bo‘yicha har tomonlama ishlay oladi.

## Ichida
01. Reels: ilgaklar va 12 ta shablon
02. 100 ta kontent g‘oyasini topish (savollar banki)
03. Sotuvdagi 14 ta psixologik trigger
04. Prognrev (isitish) rejasi va 14 kunlik namuna
05. Rad etib bo‘lmaydigan taklif (ofer) qurish
06. Sotuvchi video, karusel va post tuzilishi
07. Reels → Direkt voronka
08. Storis, kontent reja va tahlil

## Qanday yuklanadi
1. ZIP faylni oching: sichqonchaning o‘ng tugmasi → "Extract All" (Hammasini chiqarish). Telefonda: Fayllar ilovasida ZIP ustiga bosing.
2. claude.ai → Projects → AI-Marketolog loyihasi.
3. Files → ＋ → Upload from device → 01-08 fayllarni tanlang (bir vaqtda bir nechta tanlasa bo‘ladi).
4. Bu faylni (00) yuklash shart emas.
5. Loyiha ichida yangi chat oching va sinab ko‘ring: "Bilim fayllaringni o‘qi. Biznes pasportim bo‘yicha keyingi haftaga kontent reja tuzaylik."

## Muhim
- Bu fayllar umumiy metodika. Xodimni biznesingizga moslash uchun Biznes pasportini to‘ldiring va QOIDALAR orqali o‘qiting.
- Xodim taklif beradi, qarorni siz qabul qilasiz.
