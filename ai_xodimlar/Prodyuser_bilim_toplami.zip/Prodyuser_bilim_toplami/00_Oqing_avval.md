# PRODYUSER BILIM TO‘PLAMI

AI-Prodyuser uchun 7 ta o‘zbekcha bilim fayli. Ular bilan xodim zapusk va aksiyalarni boshidan oxirigacha siz bilan birga rejalashtiradi.

## Ichida
01. Zapusk strategiyasi va sotuv modellari
02. Auditoriyani o‘rganish (kastdev): so‘rovnoma va suhbat savollari
03. Zapusk rejasi: 21 kunlik shablon
04. Lid-magnit va bepul dars tuzilishi
05. Jonli efir va sotuvchi vebinar ssenariysi
06. Raqamlar: dekompozitsiya, prognoz va byudjet
07. Zapuskdan keyingi tahlil va keyingi qadam

## Qanday yuklanadi
1. ZIP faylni oching: sichqonchaning o‘ng tugmasi → "Extract All" (Hammasini chiqarish).
2. claude.ai → Projects → AI-Prodyuser loyihasi.
3. Files → ＋ → Upload from device → 01-07 fayllarni tanlang.
4. Bu faylni (00) yuklash shart emas.
5. Loyiha ichida yangi chat oching: "Bilim fayllaringni o‘qi. Keyingi oyga zapusk rejasini birga tuzaylik: avval savollaringni ber."

## Muhim
Raqamlar va foizlar taxminiy. Eng to‘g‘ri raqam: o‘z zapusklaringizdagi haqiqiy natija. Uni Biznes pasportiga yozib boring.
