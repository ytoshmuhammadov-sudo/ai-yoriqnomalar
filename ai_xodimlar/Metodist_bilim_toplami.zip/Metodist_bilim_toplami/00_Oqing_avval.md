# METODIST BILIM TO‘PLAMI

AI-Metodist uchun 7 ta o‘zbekcha bilim fayli. Ular bilan xodim mahsulot, dastur, tarif va narxni siz bilan birga tuzadi.

## Ichida
01. Mahsulot: mijozni A nuqtadan B nuqtaga olib borish
02. MVP va talabni tekshirish
03. Dastur tuzish: modullar, darslar, amaliyot
04. Mahsulot liniyasi va tariflar
05. Narx belgilash (hisob misollari bilan)
06. Mahsulot sifati va ko‘rsatkichlari
07. "Vau" effekt va mijoz yo‘li

## Qanday yuklanadi
1. ZIP faylni oching: sichqonchaning o‘ng tugmasi → "Extract All" (Hammasini chiqarish).
2. claude.ai → Projects → AI-Metodist loyihasi.
3. Files → ＋ → Upload from device → 01-07 fayllarni tanlang.
4. Bu faylni (00) yuklash shart emas.
5. Loyiha ichida yangi chat oching: "Bilim fayllaringni o‘qi. Mahsulotlarimdan 4 pog‘onali liniya tuzaylik: avval savollaringni ber."

## Muhim
Narx va raqam misollari namuna uchun. O‘z xarajatlaringiz va raqobatchilaringiz narxini Biznes pasportiga yozing: xodim shu bo‘yicha hisoblaydi.
